//返回固定数据
const mydata = {
    data1 : {
        code : 200,
        data : {
            name : "Nick",
            avatar : "wwww.4300.com",
            roles : [1,2,3],
            token:"123456789"
        },
        message : "成功"
    }

}
export default mydata